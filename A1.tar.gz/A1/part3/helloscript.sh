 #!/bin/bash          
 
 # commit 

 echo Hej hej 
 echo Hello Babar
 echo Hello John   
