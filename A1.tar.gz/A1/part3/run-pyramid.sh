#!/bin/bash  

echo Khyber